
import React, { useState } from 'react';

interface LoginViewProps {
  onLogin: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
  };

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center px-10 animate-in fade-in duration-700">
      {/* Branding */}
      <div className="mb-16 text-center">
        <h1 className="text-4xl font-black text-slate-900 tracking-tighter leading-none mb-2">
          Pool<br />Riviera Maya
        </h1>
        <div className="h-1 w-12 bg-emerald-500 mx-auto rounded-full mt-4"></div>
      </div>

      <form onSubmit={handleSubmit} className="w-full max-w-sm space-y-4">
        <div className="space-y-2">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="socio@rivieramaya.com"
            className="w-full bg-slate-50 border-none rounded-2xl px-5 py-4 text-sm font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500/20 transition-all placeholder:text-slate-300"
            required
          />
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Contraseña</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            className="w-full bg-slate-50 border-none rounded-2xl px-5 py-4 text-sm font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500/20 transition-all placeholder:text-slate-300"
            required
          />
        </div>

        <div className="pt-6">
          <button
            type="submit"
            className="w-full bg-[#0f172a] text-white py-5 rounded-2xl font-black text-[11px] uppercase tracking-[0.2em] shadow-2xl shadow-slate-200 active:scale-[0.98] transition-all"
          >
            INGRESAR
          </button>
        </div>

        <div className="mt-8 text-center">
          <button type="button" className="text-[10px] font-bold text-slate-400 uppercase tracking-widest hover:text-slate-600 transition-colors">
            ¿Olvidaste tu contraseña?
          </button>
        </div>
      </form>

      <div className="mt-auto pb-10 text-center">
        <p className="text-[9px] font-bold text-slate-300 uppercase tracking-[0.3em]">
          © 2024 Riviera Maya Investments
        </p>
      </div>
    </div>
  );
};
