
import React, { useState, useMemo } from 'react';
import { LineChart } from '../SVGCharts';
import { YEARS, MONTHS, COLORS } from '../../constants';

interface BalanceViewProps {
  selectedYear: string;
  selectedMonth: string;
}

export const BalanceView: React.FC<BalanceViewProps> = ({ selectedYear, selectedMonth }) => {
  const [timeframe, setTimeframe] = useState<'AÑO' | 'MES'>('MES');
  const [hoverValue, setHoverValue] = useState<number | null>(null);
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  // Helper to generate a deterministic seed from strings
  const getSeed = (str: string) => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash);
  };

  // Month configurations based on selectedMonth
  const monthConfig = useMemo(() => {
    const days31 = ['ENE', 'MAR', 'MAY', 'JUL', 'AGO', 'OCT', 'DIC'];
    const days30 = ['ABR', 'JUN', 'SEP', 'NOV'];
    
    let days = 31;
    let axisLabels: string[] = [];

    if (days30.includes(selectedMonth)) {
      days = 30;
      axisLabels = Array(30).fill("");
      [0, 4, 9, 14, 19, 24, 29].forEach((idx, i) => {
        axisLabels[idx] = [1, 5, 10, 15, 20, 25, 30][i].toString();
      });
    } else if (selectedMonth === 'FEB') {
      days = 28;
      axisLabels = Array(28).fill("");
      [0, 4, 9, 14, 19, 23, 27].forEach((idx, i) => {
        axisLabels[idx] = [1, 5, 10, 15, 20, 24, 28][i].toString();
      });
    } else {
      days = 31;
      axisLabels = Array(31).fill("");
      [0, 5, 10, 15, 20, 25, 30].forEach((idx, i) => {
        axisLabels[idx] = [1, 6, 11, 16, 21, 26, 31][i].toString();
      });
    }

    return { days, axisLabels };
  }, [selectedMonth]);

  // Generate deterministic yearly data based on selectedYear
  const yearData = useMemo(() => {
    const yearSeed = getSeed(selectedYear);
    // Base utility grows or fluctuates by year
    const baseValue = 400000 + (yearSeed % 200000); 
    
    // Riviera Maya Seasonal Multipliers (High: Dec-Apr, Mid: Jul-Aug, Low: Sep-Oct)
    const seasonalMultipliers = [
      1.2, 1.3, 1.15, 1.05, 0.9, 0.85, 
      1.1, 1.15, 0.75, 0.8, 1.0, 1.4
    ];

    return seasonalMultipliers.map((mult, i) => {
      // Add a small deterministic variance per month
      const variance = 1 + (Math.sin(yearSeed + i) * 0.05);
      return (baseValue / 12) * mult * variance;
    });
  }, [selectedYear]);

  // Generate deterministic monthly data based on selectedYear AND selectedMonth
  const monthData = useMemo(() => {
    const combinedSeed = getSeed(selectedYear + selectedMonth);
    const monthIndex = MONTHS.indexOf(selectedMonth);
    
    // Get the base for this specific month from the yearData
    const monthTotalBase = yearData[monthIndex];
    const avgDailyBase = monthTotalBase / monthConfig.days;

    return Array.from({ length: monthConfig.days }, (_, i) => {
      // Create a wavy trend for the month
      const trend = Math.sin((combinedSeed + i) / 3) * 0.2;
      // Weekend spikes (deterministic check for "weekends" based on seed-offset)
      const isWeekend = (combinedSeed + i) % 7 >= 5;
      const weekendBoost = isWeekend ? 1.3 : 1.0;
      
      return avgDailyBase * (1 + trend) * weekendBoost;
    });
  }, [selectedYear, selectedMonth, yearData, monthConfig.days]);

  // Calculate Aggregates
  const monthTotal = useMemo(() => monthData.reduce((acc, v) => acc + v, 0), [monthData]);
  const yearTotal = useMemo(() => yearData.reduce((acc, v) => acc + v, 0), [yearData]);

  // Full labels for hovering display context
  const fullMonthlyLabels = useMemo(() => Array.from({ length: monthConfig.days }, (_, i) => `Día ${i + 1}`), [monthConfig.days]);
  const fullYearlyLabels = useMemo(() => [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ], []);

  // Axis display labels (Yearly)
  const yearlyAxisLabels = ['ENE', 'MAR', 'MAY', 'JUL', 'SEP', 'NOV', 'DIC'];
  const fullYearlyAxisLabels = useMemo(() => {
    const arr = Array(12).fill("");
    [0, 2, 4, 6, 8, 10, 11].forEach((idx, i) => {
      arr[idx] = yearlyAxisLabels[i];
    });
    return arr;
  }, []);

  const labels = timeframe === 'MES' ? monthConfig.axisLabels : fullYearlyAxisLabels;
  const currentData = timeframe === 'MES' ? monthData : yearData;

  // Financial Summary Values
  const aggregateValue = timeframe === 'MES' ? monthTotal : yearTotal;
  const totalRevenue = aggregateValue * 1.65; // Revenue is higher than gross utility
  const operationalCosts = totalRevenue * 0.35; // 35% costs
  const netUtility = totalRevenue - operationalCosts - (aggregateValue * 0.1); // Net after extras

  // Detail display value (Header) - Dynamic on hover
  const displayValue = hoverValue !== null ? hoverValue : aggregateValue;

  // Detail label (Header) - Dynamic on hover - Optimized for requested layout
  const displayLabel = hoverIndex !== null 
    ? (timeframe === 'MES' ? fullMonthlyLabels[hoverIndex] : fullYearlyLabels[hoverIndex])
    : (timeframe === 'MES' ? `${selectedMonth} ${selectedYear}` : `Acumulado ${selectedYear}`);

  return (
    <div className="flex flex-col gap-4 animate-in fade-in duration-500">
      {/* Timeframe Split Buttons */}
      <div className="flex w-full gap-3 mb-1">
        <button
          onClick={() => {
            setTimeframe('AÑO');
            setHoverValue(null);
            setHoverIndex(null);
          }}
          className={`flex-1 py-4 rounded-2xl text-[10px] font-black tracking-[0.2em] transition-all duration-300 shadow-sm border ${
            timeframe === 'AÑO' 
              ? 'bg-[#0f172a] text-white border-[#0f172a]' 
              : 'bg-white text-slate-400 border-slate-100'
          }`}
        >
          ANUAL
        </button>
        <button
          onClick={() => {
            setTimeframe('MES');
            setHoverValue(null);
            setHoverIndex(null);
          }}
          className={`flex-1 py-4 rounded-2xl text-[10px] font-black tracking-[0.2em] transition-all duration-300 shadow-sm border ${
            timeframe === 'MES' 
              ? 'bg-[#0f172a] text-white border-[#0f172a]' 
              : 'bg-white text-slate-400 border-slate-100'
          }`}
        >
          MENSUAL
        </button>
      </div>

      {/* Main Graph Box */}
      <div className="bg-white p-6 pb-4 rounded-[2.5rem] shadow-sm overflow-hidden border border-slate-50">
        <div className="flex justify-between items-start mb-4">
          <div className="min-w-0 flex-1">
            <p className="text-slate-400 text-[9px] font-black tracking-[0.2em] uppercase mb-1 whitespace-nowrap overflow-hidden text-ellipsis">
              {hoverValue !== null ? 'UTILIDAD EN PUNTO' : 'UTILIDAD BRUTA'}
            </p>
            <h2 className={`text-3xl font-black tracking-tighter transition-all duration-300 ${hoverValue !== null ? 'text-emerald-500 scale-[1.02] origin-left' : 'text-slate-900'}`}>
              ${displayValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </h2>
          </div>
          
          {/* Shorter, more distant, and two-line period indicator */}
          <div className="text-right ml-10 shrink-0 max-w-[70px]">
            <p className="text-slate-300 text-[8px] font-black uppercase tracking-[0.2em] mb-1">PERIODO</p>
            <p className={`font-black text-[10px] leading-[1.2] uppercase transition-colors duration-200 ${hoverValue !== null ? 'text-emerald-500' : 'text-slate-400'}`}>
              {displayLabel.split(' ').map((word, i) => (
                <React.Fragment key={i}>
                  {word}
                  {i === 0 && <br />}
                </React.Fragment>
              ))}
            </p>
          </div>
        </div>

        {/* Chart Area */}
        <div className="h-[280px] flex items-center justify-center -mx-2">
          <LineChart 
            data={currentData} 
            labels={labels} 
            onHover={(val, idx) => {
              setHoverValue(val);
              setHoverIndex(idx);
            }}
          />
        </div>
      </div>

      {/* Financial Summary Square */}
      <div className="bg-[#0f172a] p-8 rounded-[2.5rem] shadow-2xl flex flex-col gap-5 border border-slate-800 relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full -translate-y-1/2 translate-x-1/2 transition-transform group-hover:scale-125"></div>
        
        <div className="relative z-10">
           <p className="text-slate-400 text-[11px] font-black uppercase tracking-[0.4em] mb-6 flex items-center gap-2">
             <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
             Resumen Financiero
           </p>
        </div>
        
        <div className="flex justify-between items-center relative z-10">
          <p className="text-slate-400 text-sm font-bold">Ingresos Operativos</p>
          <p className="text-xl font-black text-white tracking-tighter">
            ${totalRevenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
        </div>

        <div className="flex justify-between items-center relative z-10">
          <p className="text-slate-400 text-sm font-bold">Gastos de Operación</p>
          <p className="text-xl font-black text-rose-500 tracking-tighter">
            -${operationalCosts.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
        </div>

        <div className="h-px bg-slate-800 w-full my-1 relative z-10"></div>

        <div className="flex justify-between items-center relative z-10">
          <div>
            <p className="text-emerald-500 text-[10px] font-black uppercase tracking-[0.2em]">Utilidad Neta Final</p>
            <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest mt-0.5">POST-IMPUESTOS ESTIMADOS</p>
          </div>
          <p className="text-3xl font-black text-emerald-500 tracking-tighter">
            ${netUtility.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
        </div>
      </div>
    </div>
  );
};
